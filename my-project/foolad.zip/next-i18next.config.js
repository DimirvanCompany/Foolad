// const nextI18Next = require('next-i18next').default;
// module.exports = {
//     i18n: {
//       defaultLocale: 'en',
//       locales: ['fa', 'en'],
//     },
//     react: { useSuspense: false }, // این را اضافه کن
//   };
  